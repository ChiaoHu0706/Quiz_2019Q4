﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace Quiz_2019Q4
{


    public partial class Form1 : Form
    {
        //1.Class  -->  Object
        Form F = new Form();
        
        public Form1()
        {

            InitializeComponent();

        }

        
        private void Form1_DoubleClick(object sender, EventArgs e)
        {


            //PWD Control
            while (true)
            {
                string Minute = "";
                Minute = System.DateTime.Now.Minute.ToString();
                if (Minute.Length != 2) Minute = "0" + Minute;
                string input = vb.Interaction.InputBox("請輸入密碼(IMMUST分鐘)", "密碼控管");
                if (input == "IMMUST" + Minute) break;

            }

            //dynamicGeneration Form



            //2.Properties setting
            F.Text = "歡迎來到Progress世界";
            F.Width = 816;
            F.Height = 489;
            //Add 



            //dynamicGeneration Button

            //1.Class  -->  Object
            Button BN = new Button();

            //2.Properties setting
            BN.BackColor = Color.Orange;
            BN.Height = 50;
            BN.Width = 250;
            BN.Top = 0;
            BN.Left = 1;
            BN.Font = new Font(Font.FontFamily, 30, FontStyle.Bold);
            BN.Text = "ProgressBar";
            F.Controls.Add(BN);
            //3.Event Handler
            BN.Click += new EventHandler(ButtonClick);
            F.ShowDialog();

        }
        private void ButtonClick(object sender, EventArgs e)
        {
            int number;
            Random RN = new Random();
            if (!int.TryParse(vb.Interaction.InputBox("請輸入產生個數"), out number)) return;//number轉換成數字失敗就return
            F.WindowState = FormWindowState.Maximized;
            for (int i = 1; i <= number; i++)
            {
               
                ProgressBar PB = new ProgressBar();
               
                
                //2.Properties setting
                PB.ForeColor = Color.DarkViolet;
                PB.Style = ProgressBarStyle.Continuous;

                PB.BackColor = Color.Yellow;
                PB.Top = RN.Next(10, 800);
                PB.Left = RN.Next(20, 900);
                PB.Height = RN.Next(30, 80);//30配合下方的emSize大小
                PB.Width = RN.Next(85, 250);
                PB.Maximum = 20;
                PB.Value = RN.Next(0, 21);
                PB.Minimum = 0;
                PB.Step = 1;

                //3.Event Handler
                PB.Click += new EventHandler(ProgressBarClick);
                //4.Add Control
                F.Controls.Add(PB);
              

                
            }
        }
    
        private void ProgressBarClick(object sender, EventArgs e)
        {

            
            try
            {

                checked
                {
                    if (((ProgressBar)sender).Step==1)
                    {
                        if (((ProgressBar)sender).Value >= 20)
                        {
                            ((ProgressBar)sender).Step = -1;

                        }
                        else
                        {
                            ((ProgressBar)sender).Step = 1;
                            ((ProgressBar)sender).Value += ((ProgressBar)sender).Step;
                        }
                    }
                    if (((ProgressBar)sender).Step == -1)
                    {
                        if (((ProgressBar)sender).Value <=0)
                        {
                            ((ProgressBar)sender).Step = 1;
                        }
                        else
                        {
                            ((ProgressBar)sender).Step = -1;
                            ((ProgressBar)sender).Value += ((ProgressBar)sender).Step;
                        }
                    }
                }
                F.Text =  ((ProgressBar)sender).Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}